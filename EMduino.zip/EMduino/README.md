##EMduino Library
###Version 0.0.1
###Author: Brian David Arpie
------------------------------------
#####Fairfield University 2014 Senior Design Project